# Contributing to Streetmix

In the spirit of open source, **everyone** is encouraged to help improve this project! Learn more about contributing to Streetmix by reading our [documentation](https://docs.streetmix.net/contributing/intro).

Streetmix adopts the [Contributor Code of Conduct][code_of_conduct]. By participating in this project you agree to abide by its terms.

[code_of_conduct]: https://github.com/streetmix/streetmix/blob/main/CODE_OF_CONDUCT.md
