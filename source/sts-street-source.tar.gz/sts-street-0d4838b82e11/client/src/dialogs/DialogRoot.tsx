import { useSelector } from '../store/hooks.js'
import { ErrorBoundary } from '../util/ErrorBoundary.js'

// Import all dialogs here
import { AboutDialog } from './About'
import { AnalyticsDialog } from './Analytics'
import { FeatureFlagDialog } from './FeatureFlag'
import { GeotagDialog } from './Geotag'
import { SaveAsImageDialog } from './SaveAsImage'
import { SettingsDialog } from './Settings'
import { SignInDialog } from './SignIn'
import { WhatsNewDialog } from './WhatsNew'
import { NewsletterDialog } from './Newsletter'
import { UpgradeDialog } from './Upgrade'
import { PasswordResetDialog } from './PasswordReset'
import { SentimentSurveyDialog } from './SentimentSurvey'
import { ErrorDialog } from './ErrorDialog.js'
import { CoastmixTutorialComplete } from './CoastmixTutorial.js'

const DIALOG_COMPONENTS = {
  ABOUT: AboutDialog,
  ANALYTICS: AnalyticsDialog,
  FEATURE_FLAGS: FeatureFlagDialog,
  GEOTAG: GeotagDialog,
  SAVE_AS_IMAGE: SaveAsImageDialog,
  SETTINGS: SettingsDialog,
  SIGN_IN: SignInDialog,
  WHATS_NEW: WhatsNewDialog,
  NEWSLETTER: NewsletterDialog,
  UPGRADE: UpgradeDialog,
  PASSWORD_RESET: PasswordResetDialog,
  SENTIMENT_SURVEY: SentimentSurveyDialog,
  COASTMIX_TUTORIAL_COMPLETE: CoastmixTutorialComplete,
}

export function DialogRoot() {
  const name = useSelector((state) => state.dialogs.name)

  // Bail if no dialog name is provided
  if (name === null) return null

  // Get the dialog we want, then render it
  const Dialog = DIALOG_COMPONENTS[name as keyof typeof DIALOG_COMPONENTS]

  // Wrap Dialog with an ErrorBoundary wrapper to catch errors
  return (
    <ErrorBoundary fallbackComponent={<ErrorDialog />}>
      <Dialog />
    </ErrorBoundary>
  )
}
