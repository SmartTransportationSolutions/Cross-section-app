import type { UserState } from '~/src/types'
import type { StreetState } from '@streetmix/types'
import type { IntlShape, MessageValue } from 'react-intl'

export interface SocialShareProps {
  shareText: string
  shareUrl: string
}

/**
 * Returns the current page URL.
 * This may eventually change to a short URL generator - strt.mx
 */
export function getSharingUrl(): string {
  return window.location.href
}

export function getSharingMessage(
  street: StreetState,
  user: UserState,
  intl: IntlShape
): string {
  const signedIn = user.signedIn ?? false
  const userId = user.signInData?.userId ?? ''
  let message: string

  if (typeof street.creatorId === 'string') {
    if (signedIn && street.creatorId === userId) {
      if (typeof street.name === 'string') {
        message = intl.formatMessage<{ readonly streetName: MessageValue }>(
          {
            id: 'menu.share.messages.my-street',
            defaultMessage: 'Check out my street, {streetName}, on STS Street!',
          },
          { streetName: street.name }
        )
      } else {
        message = intl.formatMessage({
          id: 'menu.share.messages.my-street-unnamed',
          defaultMessage: 'Check out my street on STS Street!',
        })
      }
    } else {
      if (typeof street.name === 'string') {
        message = intl.formatMessage<{
          readonly streetCreator: MessageValue
          readonly streetName: MessageValue
        }>(
          {
            id: 'menu.share.messages.someone-elses-street',
            defaultMessage:
              'Check out {streetName} by {streetCreator} on STS Street!',
          },
          { streetName: street.name, streetCreator: `@${street.creatorId}` }
        )
      } else {
        message = intl.formatMessage<{ readonly streetCreator: MessageValue }>(
          {
            id: 'menu.share.messages.someone-elses-street-unnamed',
            defaultMessage:
              'Check out this street by {streetCreator} on STS Street!',
          },
          { streetCreator: `@${street.creatorId}` }
        )
      }
    }
  } else {
    if (typeof street.name === 'string') {
      message = intl.formatMessage<{ readonly streetName: MessageValue }>(
        {
          id: 'menu.share.messages.anonymous-creator-street',
          defaultMessage: 'Check out {streetName} on STS Street!',
        },
        { streetName: street.name }
      )
    } else {
      message = intl.formatMessage({
        id: 'menu.share.messages.anonymous-creator-street-unnamed',
        defaultMessage: 'Check out this street on STS Street!',
      })
    }
  }

  return message
}
