import { useEffect, useRef, createRef, cloneElement, useCallback } from 'react'
import { useDrop } from 'react-dnd'
import { CSSTransition, TransitionGroup } from 'react-transition-group'

import { useSelector } from '~/src/store/hooks.js'
import { usePrevious } from '~/src/util/usePrevious.js'
import type { DraggingState } from '~/src/types/index.js'
import { Segment } from '../segments/Segment.js'
import {
  TILE_SIZE,
  DRAGGING_MOVE_HOLE_WIDTH,
  DRAGGING_TYPE_RESIZE,
} from '../segments/constants.js'
import { cancelSegmentResizeTransitions } from '../segments/resizing.js'
import {
  isSegmentWithinCanvas,
  createStreetDropTargetSpec,
} from '../segments/drag_and_drop.js'

/**
 * Calculates the gap shown before or after slices while dragging another slice
 */
function makeSpaceBetweenSlices(
  sliceIndex: number,
  draggingState: DraggingState
): number {
  const { segmentBeforeEl, segmentAfterEl } = draggingState

  let gap = 0

  if (segmentBeforeEl !== null && sliceIndex >= segmentBeforeEl) {
    gap += DRAGGING_MOVE_HOLE_WIDTH

    if (segmentAfterEl === null) {
      gap += DRAGGING_MOVE_HOLE_WIDTH
    }
  }

  if (segmentAfterEl !== null && sliceIndex > segmentAfterEl) {
    gap += DRAGGING_MOVE_HOLE_WIDTH

    if (segmentBeforeEl === null) {
      gap += DRAGGING_MOVE_HOLE_WIDTH
    }
  }

  return gap
}

interface StreetEditableProps {
  resizeType: number | undefined
  setBoundaryWidth: (node: HTMLElement | null) => void
  updatePerspective: (el: HTMLElement | null) => void
  draggingType?: number
  ref: React.RefObject<HTMLDivElement | null>
}

export function StreetEditable(props: StreetEditableProps) {
  const { resizeType, setBoundaryWidth, updatePerspective, draggingType, ref } =
    props
  const street = useSelector((state) => state.street)
  const immediateRemoval = useSelector((state) => state.ui.immediateRemoval)
  const draggingState = useSelector((state) => state.ui.draggingState)

  // Internal "state", but does not affect renders, so it is not React state
  const withinCanvas = useRef<boolean>(false)

  // According to "rule of hooks", useRef() must not be called in a loop
  // This is a top-level container to manage a list of refs as a workaround
  // for CSSTransition's reliance on deprecated findDOMNode
  const childRefs = useRef<Record<string, React.RefObject<HTMLDivElement>>>({})

  // Keep previous state for comparisons (ported from legacy behavior)
  const prevProps = usePrevious({
    resizeType,
    draggingType,
    street,
    draggingState,
  })

  // Set up drop target
  const dropTargetSpec = createStreetDropTargetSpec(street, ref)
  const [, drop] = useDrop(dropTargetSpec)

  const updateWithinCanvas = useCallback(
    (event: MouseEvent | TouchEvent): void => {
      if (ref.current === null) return

      const newValue = isSegmentWithinCanvas(event, ref.current)

      if (newValue) {
        document.body.classList.remove('not-within-canvas')
      } else {
        document.body.classList.add('not-within-canvas')
      }

      if (withinCanvas.current !== newValue) {
        withinCanvas.current = newValue
      }
    },
    [ref]
  )

  useEffect(() => {
    window.addEventListener('dragover', updateWithinCanvas)
    window.addEventListener('touchmove', updateWithinCanvas)

    return () => {
      window.removeEventListener('dragover', updateWithinCanvas)
      window.removeEventListener('touchmove', updateWithinCanvas)
    }
  }, [updateWithinCanvas])

  useEffect(() => {
    if (prevProps === null) return
    if (
      resizeType !== undefined ||
      (prevProps.draggingType === DRAGGING_TYPE_RESIZE &&
        draggingType !== undefined)
    ) {
      setBoundaryWidth(ref.current)
    }
  }, [resizeType, draggingType, setBoundaryWidth, prevProps, ref])

  useEffect(() => {
    if (
      prevProps?.street.id !== street.id ||
      prevProps?.street.width !== street.width
    ) {
      cancelSegmentResizeTransitions()
    }
  }, [street.id, street.width, prevProps])

  function handleSwitchSliceAway(el: HTMLDivElement, sliceIndex: number): void {
    // Targeting first child node instead of el because of wrapper div workaround
    // for CSSTransition
    const childNode = el.firstChild as HTMLDivElement
    if (childNode === null) return

    const left = calculateSlicePosition(sliceIndex)
    childNode.style.left = `${left}px`

    updatePerspective(childNode)
  }

  function calculateSlicePosition(sliceIndex: number): number {
    const { segments, remainingWidth } = street

    let currPos = 0

    for (let i = 0; i < sliceIndex; i++) {
      const width =
        draggingState.draggedSegment === i ? 0 : segments[i].width * TILE_SIZE
      currPos += width
    }

    let mainLeft = remainingWidth
    // Do this additional calculation if the slice is in the street
    // (meaning that it is indexed in the array of slices)
    if (typeof draggingState.draggedSegment === 'number') {
      mainLeft += segments[draggingState.draggedSegment].width
    }

    mainLeft = (mainLeft * TILE_SIZE) / 2

    // Only need to check if the draggedSegment isn't null here, because
    // slices being dragged from palette will have a value of `undefined`
    if (draggingState.draggedSegment !== null && withinCanvas.current) {
      mainLeft -= DRAGGING_MOVE_HOLE_WIDTH
      const gap = makeSpaceBetweenSlices(sliceIndex, draggingState)
      return mainLeft + currPos + gap
    } else {
      return mainLeft + currPos
    }
  }

  function onExitAnimations(child: React.ReactElement): React.ReactElement {
    return cloneElement(child, {
      exit: !immediateRemoval,
    })
  }

  function renderStreetSegments(): React.ReactNode {
    const { segments, units } = street
    const streetId = street.id

    return segments.map((segment, i) => {
      const segmentLeft = calculateSlicePosition(i)
      const key = `${streetId}.${segment.id}`
      // Refs are created with createRef and then stored in parent `refs`
      const ref = createRef<HTMLDivElement>()
      childRefs.current[key] = ref

      const segmentEl = (
        <CSSTransition
          key={key}
          timeout={250}
          classNames="slice-remove"
          exit={!immediateRemoval}
          onExit={() => {
            if (ref.current === null) return
            handleSwitchSliceAway(ref.current, i)
          }}
          unmountOnExit
          nodeRef={ref}
        >
          {/* This wrapper element is a workaround for CSSTransition depending on
              findDOMNode, which is deprecated. We just need a DOM element to
              attach a ref to. This introduces a lot of bugs, unfortunately. */}
          <div ref={ref}>
            <Segment
              sliceIndex={i}
              segment={{ ...segment }}
              units={units}
              segmentLeft={segmentLeft}
            />
          </div>
        </CSSTransition>
      )

      return segmentEl
    })
  }

  const style = {
    width: street.width * TILE_SIZE + 'px',
  }

  return (
    <div id="street-section-editable" key={street.id} style={style} ref={ref}>
      <div style={{ width: '100%', height: '100%' }} ref={drop}>
        <TransitionGroup
          key={street.id}
          component={null}
          enter={false}
          childFactory={onExitAnimations}
        >
          {renderStreetSegments()}
        </TransitionGroup>
      </div>
    </div>
  )
}
