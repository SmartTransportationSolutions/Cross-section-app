import { brand } from '@sts-street/branding'
import { FormattedMessage } from 'react-intl'

import { useSelector } from '../store/hooks.js'
import { Button } from '../ui/Button.js'
import { ExternalLink } from '../ui/ExternalLink.js'
import { doSignIn } from '../users/authentication.js'
import { goReload, goHome, goNewStreet } from './routing.js'
import { ERRORS } from './errors.js'

export function BlockingError() {
  const errorType = useSelector((state) => state.errors.errorType)

  let title: React.ReactElement | string
  let description: React.ReactElement | string = ''
  let cta: React.ReactElement | string = ''

  const homeButton = (
    <Button primary onClick={goHome}>
      <FormattedMessage
        id="error.button.return"
        defaultMessage="Return to STS Street"
      />
    </Button>
  )
  const reloadButton = (
    <Button primary onClick={goReload}>
      <FormattedMessage
        id="error.button.reload"
        defaultMessage="Reload the page"
      />
    </Button>
  )
  const tryAgainButton = (
    <Button primary onClick={goNewStreet}>
      <FormattedMessage
        id="error.button.try-again"
        defaultMessage="Try again"
      />
    </Button>
  )
  const signInButton = (
    <Button primary onClick={doSignIn}>
      <FormattedMessage id="menu.item.sign-in" defaultMessage="Sign in" />
    </Button>
  )
  const pleaseLetUsKnow = (
    <FormattedMessage
      id="error.please-try-again-contact-us"
      defaultMessage="Please try again later. If you still need help, please <a>contact us</a>."
      values={{
        a: (chunks) => (
          <ExternalLink href={`mailto:${brand.supportEmail}`}>
            {chunks}
          </ExternalLink>
        ),
      }}
    />
  )
  const needHelpLink = (
    <p className="error-help-link">
      <ExternalLink href={brand.troubleshootingUrl}>
        <FormattedMessage
          id="error.need-help-link"
          defaultMessage="Need help?"
        />
      </ExternalLink>
    </p>
  )

  switch (errorType) {
    // Deprecated. Server should be handling 404 not found errors. Keep this
    // as backup for now.
    case ERRORS.NOT_FOUND:
      title = (
        <FormattedMessage
          id="error.page-not-found-title"
          defaultMessage="Page not found."
        />
      )
      description = (
        <p>
          <FormattedMessage
            id="error.page-not-found-description"
            defaultMessage="Oh, boy. There is no page with this address!"
          />
        </p>
      )
      cta = homeButton
      break
    case ERRORS.SIGN_OUT:
      title = (
        <FormattedMessage
          id="error.sign-out-title"
          defaultMessage="You are now signed out."
        />
      )
      cta = homeButton
      break
    case ERRORS.NO_STREET:
      title = (
        <FormattedMessage
          id="msg.no-street"
          defaultMessage="No street selected."
        />
      )
      break
    case ERRORS.GALLERY_STREET_FAILURE:
      title = (
        <FormattedMessage
          id="msg.having-trouble"
          defaultMessage="Having trouble…"
        />
      )
      description = (
        <p>
          <FormattedMessage
            id="error.gallery-street-failure-description"
            defaultMessage="We’re having trouble loading this street."
          />
        </p>
      )
      break
    case ERRORS.FORCE_RELOAD_SIGN_OUT:
      title = (
        <FormattedMessage
          id="error.reload-sign-out-title"
          defaultMessage="You signed out in another window."
        />
      )
      description = (
        <p>
          <FormattedMessage
            id="error.please-reload"
            defaultMessage="Please reload this page to return to STS Street."
          />
        </p>
      )
      cta = reloadButton
      break
    case ERRORS.FORCE_RELOAD_SIGN_IN:
      title = (
        <FormattedMessage
          id="error.reload-sign-in-title"
          defaultMessage="You signed in in another window."
        />
      )
      description = (
        <p>
          <FormattedMessage
            id="error.please-reload"
            defaultMessage="Please reload this page to return to STS Street."
          />
        </p>
      )
      cta = reloadButton
      break
    case ERRORS.AUTH_EXPIRED:
      title = (
        <FormattedMessage
          id="error.auth-expired"
          defaultMessage="We automatically signed you out due to inactivity."
        />
      )
      description = (
        <p>
          <FormattedMessage
            id="error.sign-in-again"
            defaultMessage="Please sign in again."
          />
        </p>
      )
      cta = (
        <>
          {signInButton}
          &nbsp;
          {homeButton}
        </>
      )
      break
    case ERRORS.STREET_DELETED_ELSEWHERE:
      title = (
        <FormattedMessage
          id="error.street-deleted-elsewhere-title"
          defaultMessage="This street has been deleted elsewhere."
        />
      )
      description = (
        <p>
          <FormattedMessage
            id="error.street-deleted-elsewhere-description"
            defaultMessage="This street has been deleted in another browser."
          />
        </p>
      )
      cta = homeButton
      break
    case ERRORS.NEW_STREET_SERVER_FAILURE:
      title = (
        <FormattedMessage
          id="msg.having-trouble"
          defaultMessage="Having trouble…"
        />
      )
      description = (
        <p>
          <FormattedMessage
            id="msg.trouble-loading"
            defaultMessage="We’re having trouble loading STS Street."
          />
        </p>
      )
      cta = (
        <>
          {tryAgainButton}
          {needHelpLink}
        </>
      )
      break
    case ERRORS.SIGN_IN_SERVER_FAILURE:
      title = (
        <FormattedMessage
          id="msg.having-trouble"
          defaultMessage="Having trouble…"
        />
      )
      description = (
        <p>
          <FormattedMessage
            id="msg.trouble-loading"
            defaultMessage="We’re having trouble loading STS Street."
          />
          <br />
          <FormattedMessage
            id="error.error-code"
            defaultMessage="(Error {code}.)"
            values={{ code: '15A' }}
          />
        </p>
      )
      cta = (
        <>
          {tryAgainButton}
          {needHelpLink}
        </>
      )
      break
    case ERRORS.SIGN_IN_401:
      title = (
        <FormattedMessage
          id="msg.having-trouble"
          defaultMessage="Having trouble…"
        />
      )
      description = (
        <p>
          <FormattedMessage
            id="msg.trouble-loading"
            defaultMessage="We’re having trouble loading STS Street."
          />
          <br />
          <FormattedMessage
            id="error.error-code"
            defaultMessage="(Error {code}.)"
            values={{ code: 'RM1' }}
          />
        </p>
      )
      cta = (
        <>
          {tryAgainButton}
          {needHelpLink}
        </>
      )
      break
    case ERRORS.STREET_DATA_FAILURE:
      title = (
        <FormattedMessage
          id="msg.having-trouble"
          defaultMessage="Having trouble…"
        />
      )
      description = (
        <p>
          <FormattedMessage
            id="msg.trouble-loading"
            defaultMessage="We’re having trouble loading STS Street."
          />
          <br />
          <FormattedMessage
            id="error.error-code"
            defaultMessage="(Error {code}.)"
            values={{ code: '9B' }}
          />
        </p>
      )
      cta = (
        <>
          {tryAgainButton}
          {needHelpLink}
        </>
      )
      break
    // Deprecated.
    case ERRORS.UNSUPPORTED_BROWSER:
      title = (
        <FormattedMessage
          id="error.unsupported-browser-title"
          defaultMessage="STS Street doesn’t work on your browser."
        />
      )
      description = (
        <>
          <p>
            <FormattedMessage
              id="error.unsupported-browser-description"
              defaultMessage="Sorry about that. You might want to try <chrome_link>Chrome</chrome_link>, <firefox_link>Firefox</firefox_link>, <edge_link>Microsoft Edge</edge_link>, or Safari."
              values={{
                chrome_link: (chunks) => (
                  <ExternalLink href="https://www.google.com/chrome">
                    {chunks}
                  </ExternalLink>
                ),
                firefox_link: (chunks) => (
                  <ExternalLink href="https://www.mozilla.org/firefox">
                    {chunks}
                  </ExternalLink>
                ),
                edge_link: (chunks) => (
                  <ExternalLink href="https://www.microsoft.com/en-us/windows/microsoft-edge">
                    {chunks}
                  </ExternalLink>
                ),
              }}
            />
          </p>
          <p>
            <FormattedMessage
              id="error.unsupported-browser-internet-explorer"
              defaultMessage="Are you on Internet Explorer? <a>Find out more.</a>"
              values={{
                a: (chunks) => (
                  <ExternalLink href={`${brand.docsUrl}user-guide/support/faq`}>
                    {chunks}
                  </ExternalLink>
                ),
              }}
            />
          </p>
          <p>
            <FormattedMessage
              id="error.unsupported-browser-contact-us"
              defaultMessage="If you think your browser should be supported, please <a>contact us</a>."
              values={{
                a: (chunks) => (
                  <ExternalLink href={`mailto:${brand.supportEmail}`}>
                    {chunks}
                  </ExternalLink>
                ),
              }}
            />
          </p>
        </>
      )
      break
    default:
      // also ERRORS.GENERIC_ERROR
      title = (
        <FormattedMessage
          id="error.generic-error-title"
          defaultMessage="Something went wrong."
        />
      )
      description = (
        <p>
          <FormattedMessage
            id="error.generic-error-description"
            defaultMessage="We’re sorry – something went wrong."
          />
          &nbsp;{pleaseLetUsKnow}
        </p>
      )
      cta = homeButton
      break
  }

  if (errorType !== null) {
    return (
      <div id="error">
        <div className="error-content">
          {errorType !== ERRORS.NO_STREET && <div className="streetmix-logo" />}
          <div className="error-text">
            <h1>{title}</h1>
            {description}
          </div>
          {cta}
        </div>
      </div>
    )
  }

  return null
}
