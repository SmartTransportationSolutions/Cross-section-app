import { vi } from 'vitest'
import { screen, waitFor } from '@testing-library/react'
import { userEvent } from '@testing-library/user-event'

import { render } from '~/test/helpers/render.js'
import MOCK_STREET from '~/test/fixtures/street.json'
import { closeGallery } from '~/src/store/actions/gallery.js'
import { Gallery } from './Gallery.js'
import { switchGalleryStreet } from './index'

vi.mock('./index.js')
vi.mock('../app/errors.js')
vi.mock('../streets/thumbnail.js')
vi.mock('../streets/xhr.js')
vi.mock('../store/actions/gallery.js', () => ({
  closeGallery: vi.fn(() => ({ type: 'MOCK_ACTION' })),
}))

const defaultPaginationValues = {
  page: 1,
  limit: 100,
  total: 1,
  totalPages: 1,
  hasNextPage: false,
  hasPreviousPage: false,
}

const initialState = {
  gallery: {
    userId: 'foo',
    visible: true,
    mode: 'gallery',
    streets: [MOCK_STREET],
    pagination: defaultPaginationValues,
  },
  street: {
    id: '2556be10-df45-11e9-92a0-b5e383de159b',
  },
  user: {
    signedIn: true,
    signInData: {
      userId: 'foo',
    },
  },
}

describe('Gallery', () => {
  it('renders main gallery view for user’s own streets', async () => {
    const { getByAltText, asFragment } = render(<Gallery />, { initialState })

    await waitFor(() => {
      // Wait for profile image to load with user id in alt text
      expect(getByAltText('foo')).toBeInTheDocument()
      expect(asFragment()).toMatchSnapshot()
    })
  })

  it('renders main gallery view for another user’s streets', async () => {
    const { getByAltText, asFragment } = render(<Gallery />, {
      initialState: {
        ...initialState,
        user: {
          signedIn: true,
          signInData: {
            // We are signed in as user 'baz'
            // We're displaying the gallery for user 'foo'
            userId: 'baz',
          },
        },
      },
    })

    await waitFor(() => {
      // Wait for profile image to load with user id in alt text
      expect(getByAltText('foo')).toBeInTheDocument()
      expect(asFragment()).toMatchSnapshot()
    })
  })

  it('renders global gallery view', async () => {
    const initialState = {
      gallery: {
        userId: null,
        visible: true,
        mode: 'gallery',
        streets: [MOCK_STREET],
        pagination: defaultPaginationValues,
      },
      street: {
        id: '2556be10-df45-11e9-92a0-b5e383de159b',
      },
      user: {
        signedIn: false,
      },
    }

    const { getByText, asFragment } = render(<Gallery />, { initialState })

    await waitFor(() => {
      // Wait for street to load
      expect(getByText('Baz')).toBeInTheDocument()
      expect(asFragment()).toMatchSnapshot()
    })
  })

  it('renders loading', async () => {
    const initialState = {
      gallery: {
        visible: true,
        mode: 'loading',
        streets: [],
        pagination: defaultPaginationValues,
      },
    }

    const { asFragment } = render(<Gallery />, { initialState })

    await waitFor(() => {
      expect(asFragment()).toMatchSnapshot()
    })
  })

  it('renders error', async () => {
    const initialState = {
      gallery: {
        visible: true,
        mode: 'error',
        streets: [],
        pagination: defaultPaginationValues,
      },
    }

    render(<Gallery />, { initialState })

    await waitFor(() => {
      expect(
        screen.getByText('Failed to load the gallery.')
      ).toBeInTheDocument()
    })
  })

  it('closes on shield click', async () => {
    render(<Gallery />, { initialState })

    await userEvent.click(screen.getByTestId('gallery-shield'))

    expect(closeGallery).toHaveBeenCalledTimes(1)
  })

  describe('street item', () => {
    it('selects street', async () => {
      const { getByText } = render(<Gallery />, {
        initialState,
      })

      await waitFor(async () => {
        await userEvent.click(getByText('Baz'))
        expect(switchGalleryStreet).toHaveBeenCalledWith(initialState.street.id)
      })
    })

    it('deletes street', async () => {
      const { getByTitle, queryByTitle } = render(<Gallery />, {
        initialState,
      })

      await waitFor(async () => {
        await userEvent.click(getByTitle('Delete street'))

        // There's only one street "displayed" so we expect no "delete street"
        // button to be rendered anymore, since that street should be deleted.
        expect(queryByTitle('Delete street')).not.toBeInTheDocument()
      })
    })
  })
})
