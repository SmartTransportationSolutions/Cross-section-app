import { getBoundaryImageHeight } from '../boundary'
import { TILE_SIZE, BOUNDARY_WIDTH } from '../segments/constants.js'
import { deleteStreetImage } from '../util/api.js'
import store, { observeStore, type RootState } from '../store'
import { drawStreetThumbnail } from './thumbnail.js'
import { trimStreetData } from './data_model.js'

import type { StreetState } from '@streetmix/types'

// This can be adjusted to create much more hi-definition images
const SAVE_AS_IMAGE_DPI = 2.0

const SAVE_AS_IMAGE_MIN_HEIGHT = 400
const SAVE_AS_IMAGE_MIN_HEIGHT_WITH_STREET_NAME = SAVE_AS_IMAGE_MIN_HEIGHT + 150
const SAVE_AS_IMAGE_BOTTOM_PADDING = 60

// Used in thumbnail
// TODO: a way to remove the circular dependency?!
export const SAVE_AS_IMAGE_LABEL_PADDING = 65

export async function getStreetImage(
  street: StreetState,
  transparentSky: boolean,
  labels: boolean,
  streetName: boolean,
  dpi = SAVE_AS_IMAGE_DPI,
  watermark = true,
  locale: string | null = null
): Promise<HTMLCanvasElement> {
  const width = TILE_SIZE * street.width + BOUNDARY_WIDTH * 2

  const leftHeight = getBoundaryImageHeight(
    street.boundary.left.variant,
    'left',
    street.boundary.left.floors
  )
  const rightHeight = getBoundaryImageHeight(
    street.boundary.right.variant,
    'right',
    street.boundary.right.floors
  )

  let height = Math.max(leftHeight, rightHeight)

  if (height < SAVE_AS_IMAGE_MIN_HEIGHT) {
    height = SAVE_AS_IMAGE_MIN_HEIGHT
  }

  if (streetName && height < SAVE_AS_IMAGE_MIN_HEIGHT_WITH_STREET_NAME) {
    height = SAVE_AS_IMAGE_MIN_HEIGHT_WITH_STREET_NAME
  }

  height += SAVE_AS_IMAGE_BOTTOM_PADDING

  if (labels) {
    height += SAVE_AS_IMAGE_LABEL_PADDING
  }

  const el = document.createElement('canvas')
  el.width = width * dpi
  el.height = height * dpi

  const ctx = el.getContext('2d')

  if (!ctx) {
    throw new Error('Unable to create canvas rendering context')
  }

  await drawStreetThumbnail(ctx, street, {
    width,
    height,
    dpi,
    multiplier: 1.0,
    silhouette: false,
    transparentSky,
    labels,
    streetName,
    watermark,
    locale,
  })

  return el
}

// Save thumbnail if necessary every 30 minutes (1800000 ms)
const SAVE_THUMBNAIL_TIME_INTERVAL = 1800000
let _lastSavedTimestamp

// Temporarily disabled. Commented out to prevent eslint errors.
// let _savedThumbnail

export const SAVE_THUMBNAIL_EVENTS = {
  INITIAL: 'INITIAL',
  SHARE: 'SHARE',
  TIMER: 'TIMER',
  BEFOREUNLOAD: 'BEFOREUNLOAD',
  PREVIOUS_STREET: 'PREVIOUS_STREET',
} as const

export function isThumbnailSaved(): boolean {
  // return _savedThumbnail
  return true
}

export function initStreetThumbnailSubscriber() {
  // Save street thumbnail on initial street render.
  saveStreetThumbnail(
    trimStreetData(store.getState().street),
    SAVE_THUMBNAIL_EVENTS.INITIAL
  )

  const select = (state: RootState) => {
    const street = { editCount: state.street.editCount, id: state.street.id }
    return JSON.stringify(street)
  }

  const onChange = () => {
    const timestamp = Date.now()
    const timeElapsed = timestamp - _lastSavedTimestamp
    // _savedThumbnail = false

    // Save street thumbnail every 30 minutes if any changes to street.
    if (timeElapsed && timeElapsed >= SAVE_THUMBNAIL_TIME_INTERVAL) {
      const street = trimStreetData(store.getState().street)
      saveStreetThumbnail(street, SAVE_THUMBNAIL_EVENTS.TIMER)
    }
  }

  return observeStore(select, onChange)
}

// Creates street thumbnail and uploads thumbnail to cloudinary.
// TEMPORARILY DISABLED.
export async function saveStreetThumbnail(
  _street: Partial<StreetState>,
  _event: string
): Promise<void> {
  // if (_savedThumbnail) return
  // _lastSavedTimestamp = Date.now()
  // const thumbnail = getStreetImage(street, false, false, true, 2.0, false)
  // try {
  //   // .toDataURL is not available on IE11 when SVGs are part of the canvas.
  //   const dataUrl = thumbnail.toDataURL('image/png')
  //   const details = {
  //     image: dataUrl,
  //     event,
  //     editCount: street.editCount,
  //     creatorId: street.creatorId
  //   }
  //   // Check if street is default or empty street.
  //   // If a signed-in user adopts an existing street, the editCount is set to 0 even if it isn't a DEFAULT or EMPTY street.
  //   // Only if the street has an editCount = 0 and has no originalStreetId, should we set the streetType.
  //   if (street.editCount === 0 && !street.originalStreetId) {
  //     const streetType = (street.segments.length) ? 'DEFAULT_STREET' : 'EMPTY_STREET'
  //     details.streetType = streetType
  //   }
  //   const url = '/api/v1/streets/' + street.id + '/image'
  //   const options = {
  //     method: 'POST',
  //     body: JSON.stringify(details),
  //     headers: {
  //       'Content-Type': 'text/plain'
  //     }
  //   }
  //   const response = await window.fetch(url, options)
  //   if (response.ok) {
  //     console.log('Updated street thumbnail.')
  //     _savedThumbnail = true
  //   } else {
  //     const results = await response.json()
  //     // For now, we are only saving street thumbnails once (when the street first renders)
  //     // Any other situation (i.e. timer, share menu) returns an error that does not need to be logged.
  //     if (results.status !== 501) {
  //       throw new Error(results.msg)
  //     }
  //   }
  // } catch (err) {
  //   console.log('Unable to save street thumbnail. ', err)
  // }
}

// Handles removing street thumbnail from cloudinary.
export async function deleteStreetThumbnail(streetId: string): Promise<void> {
  try {
    // As this function returns a Promise, awaiting it allows rejected
    // Promises to be caught by the `catch` block below.
    await deleteStreetImage(streetId)
  } catch (error) {
    console.error('Unable to delete street thumbnail.', error)
  }
}
