import clone from 'just-clone'

import { ERRORS } from '~/src/app/errors.js'
import { formatMessage } from '~/src/locales/locale.js'
import { checkSeaLevel } from '~/src/plugins/coastmix/sea_level.js'
import {
  RESIZE_TYPE_INCREMENT,
  RESIZE_TYPE_PRECISE_DRAGGING,
  resolutionForResizeType,
  normalizeSegmentWidth,
  cancelSegmentResizeTransitions,
} from '~/src/segments/resizing.js'
import { getSlopeValues } from '~/src/segments/slope.js'
import { getVariantInfo } from '~/src/segments/variant_utils.js'
import {
  setIgnoreStreetChanges,
  setLastStreet,
  saveStreetToServerIfNecessary,
} from '~/src/streets/data_model.js'
import { applyWarningsToSlices } from '~/src/streets/warnings.js'
import { recalculateWidth } from '~/src/streets/width.js'
import { saveStreetToServer } from '~/src/streets/xhr.js'
import apiClient from '~/src/util/api.js'
import { showError } from '../slices/errors.js'
import { updateSettings } from '../slices/settings.js'
import { addToast } from '../slices/toasts.js'
import {
  updateStreetWidth,
  updateSegments,
  removeSegment,
  clearSegments,
  changeSegmentWidth,
  updateStreetData,
  updateShowAnalytics,
  updateCapacitySource,
  saveStreetId,
  saveOriginalStreetId,
} from '../slices/street.js'
import { setInfoBubbleMouseInside } from '../slices/infoBubble.js'
import { setActiveSegment, setImmediateRemoval } from '../slices/ui.js'
import { setSliceWarnings } from '../slices/warnings.js'

import { setFloodDetails } from '../slices/coastmix.js'
import type { Dispatch, RootState } from '../index.js'
import type {
  SliceItem,
  StreetAPIResponse,
  StreetState,
} from '@streetmix/types'

/**
 * `updateStreetWidth` as a thunk action that automatically
 * dispatches segmentChanged
 */
export function updateStreetWidthAction(width: number) {
  return async (dispatch: Dispatch) => {
    await dispatch(updateStreetWidth(width))
    await dispatch(segmentsChanged())
  }
}

/**
 * `updateStreetData` as a thunk action that also makes sure that
 * `immediateRemoval` is true
 */
export function updateStreetDataAction(data: Partial<StreetState>) {
  return async (dispatch: Dispatch) => {
    await dispatch(setImmediateRemoval(true))
    await dispatch(updateStreetData(data))
  }
}

export const segmentsChanged = (force = false) => {
  return async (dispatch: Dispatch, getState: () => RootState) => {
    const { street, coastmix } = getState()
    const { seaLevelRise, stormSurge } = coastmix

    const calculatedWidths = recalculateWidth(street)

    // Original slices state is read-only, so we need to clone it to modify
    // and update its properties.
    const clonedSlices: SliceItem[] = street.segments.map((slice, index) => {
      // Calculate slope values, if needed
      let slopeValues: number[]
      if (slice.slope.on && slice.slope.values.length === 0) {
        // If we don't have slope values, create it using adjacent values
        slopeValues = getSlopeValues(street, index)
      } else {
        // Else, reuse previous values
        slopeValues = slice.slope.values
      }

      return {
        // This shallow-copies the original data, which is generally fine
        // for everything but two properties
        ...slice,
        // This will be modified by slope calculation
        slope: {
          on: slice.slope.on ?? false,
          values: slopeValues,
        },
      }
    })
    await dispatch(
      updateSegments(
        clonedSlices,
        calculatedWidths.occupiedWidth.toNumber(),
        calculatedWidths.remainingWidth.toNumber()
      )
    )

    const sliceWarnings = applyWarningsToSlices(
      clonedSlices,
      street,
      calculatedWidths
    )
    await dispatch(setSliceWarnings(sliceWarnings))

    // Calculate flood details
    // This is using a stale version of `street` and might not include
    // the updated occupiedWidth, remainingWidth etc? but it still seems to
    // be okay.
    const floodDetails = checkSeaLevel(street, seaLevelRise, stormSurge)
    dispatch(setFloodDetails(floodDetails))

    // ToDo: Refactor this out to be dispatched as well
    // Forcing a save is necessary when the data to be saved is not in the
    // street data blob (e.g. plugins data)
    saveStreetToServerIfNecessary(force)
  }
}

export const removeSegmentAction = (segmentIndex: number) => {
  return async (dispatch: Dispatch) => {
    await dispatch(setImmediateRemoval(false))
    await dispatch(removeSegment(segmentIndex))
    await dispatch(segmentsChanged())

    // Reset various UI states
    await dispatch(setActiveSegment(null))
    await dispatch(setInfoBubbleMouseInside(false))

    await dispatch(
      addToast({
        message: formatMessage(
          'toast.segment-deleted',
          'The segment has been removed.'
        ),
        component: 'TOAST_UNDO',
      })
    )
  }
}

export const clearSegmentsAction = () => {
  return async (dispatch: Dispatch) => {
    await dispatch(setImmediateRemoval(true))
    await dispatch(clearSegments())
    await dispatch(segmentsChanged())

    // Reset various UI states
    await dispatch(setActiveSegment(null))
    await dispatch(setInfoBubbleMouseInside(false))

    await dispatch(
      addToast({
        message: formatMessage(
          'toast.all-segments-deleted',
          'All segments have been removed.'
        ),
        component: 'TOAST_UNDO',
      })
    )
  }
}

export const setShowAnalytics = (isVisible: boolean) => {
  return async (dispatch: Dispatch) => {
    await dispatch(updateShowAnalytics(isVisible))
    await dispatch(segmentsChanged())
  }
}

export const setCapacitySource = (source: string) => {
  return async (dispatch: Dispatch) => {
    await dispatch(updateCapacitySource(source))
    await dispatch(segmentsChanged())
  }
}

export const incrementSegmentWidth = (
  sliceIndex: number,
  add: boolean,
  precise: boolean,
  resizeType: number = RESIZE_TYPE_INCREMENT
) => {
  return async (dispatch: Dispatch, getState: () => RootState) => {
    const units = getState().street.units
    const origWidth = getState().street.segments[sliceIndex].width

    let resolution

    if (precise) {
      resolution = resolutionForResizeType(RESIZE_TYPE_PRECISE_DRAGGING, units)
    } else {
      resolution = resolutionForResizeType(resizeType, units)
    }

    let increment = resolution

    if (!add) {
      increment = -increment
    }

    // When width values are imprecise (e.g. after unit conversion), then
    // increment to nearest precise value, rather than increment first and
    // then make precise
    const adjustedWidth = normalizeSegmentWidth(origWidth, resolution)

    let width
    if (origWidth !== adjustedWidth) {
      if (add && adjustedWidth > origWidth) {
        width = adjustedWidth
      } else if (!add && adjustedWidth < origWidth) {
        width = adjustedWidth
      } else {
        width = normalizeSegmentWidth(origWidth + increment, resolution)
      }
    } else {
      width = normalizeSegmentWidth(origWidth + increment, resolution)
    }

    cancelSegmentResizeTransitions()
    await dispatch(changeSegmentWidth(sliceIndex, width))
    await dispatch(segmentsChanged())
  }
}

const createStreetFromResponse = (response: StreetAPIResponse): StreetState => {
  // This is where the response format gets flattened for Redux state
  // Not sure if we have to do all this, tbh...
  const street = clone(response.data.street) as StreetState
  street.creatorId = response.creatorId || null
  street.originalStreetId = response.originalStreetId || null
  street.updatedAt = response.updatedAt || undefined
  street.name = response.name || null
  street.location = response.data.street.location || null
  street.editCount = response.data.street.editCount || 0
  street.segments = street.segments.map((segment) => {
    segment.variant = getVariantInfo(segment.type, segment.variantString)
    return segment
  })

  return street
}

// Currently not being used but could replace fetchLastStreet in xhr.js
export const getLastStreet = () => {
  return async (dispatch: Dispatch, getState: () => RootState) => {
    const lastStreetId = getState().app.priorLastStreetId
    const { id, namespacedId } = getState().street

    if (!lastStreetId) return

    try {
      const response = await apiClient.getStreet(lastStreetId)
      const data = response.data
      const street = createStreetFromResponse(data)
      setIgnoreStreetChanges(true)
      await dispatch(
        updateSettings({
          lastStreetId: data.id,
          lastStreetNamespacedId: data.namespacedId,
          lastStreetCreatorId: street.creatorId,
        })
      )
      dispatch(updateStreetData(street))
      if (id) {
        dispatch(saveStreetId(id, namespacedId))
      } else {
        dispatch(saveStreetId(data.id, data.namespacedId))
      }
      dispatch(saveOriginalStreetId(lastStreetId))
      await dispatch(segmentsChanged())
      setIgnoreStreetChanges(false)
      setLastStreet()
      saveStreetToServer(false)
    } catch (error) {
      dispatch(showError(ERRORS.NEW_STREET_SERVER_FAILURE, true))
    }
  }
}
