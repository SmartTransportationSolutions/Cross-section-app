import { round } from '@streetmix/utils'

import { setIgnoreStreetChanges } from '../streets/data_model.js'
import { SETTINGS_UNITS_IMPERIAL } from '../users/constants.js'
import store from '../store'
import { segmentsChanged } from '../store/actions/street.js'
import { changeSegmentWidth } from '../store/slices/street.js'
import { setDraggingType } from '../store/slices/ui.js'
import {
  TILE_SIZE,
  MIN_SEGMENT_WIDTH,
  MAX_SEGMENT_WIDTH,
  MIN_ELEVATION,
  MAX_ELEVATION_METRIC,
  MAX_ELEVATION_IMPERIAL,
  DRAGGING_TYPE_NONE,
  SEGMENT_WIDTH_RESOLUTION_IMPERIAL,
  SEGMENT_WIDTH_CLICK_INCREMENT_IMPERIAL,
  SEGMENT_WIDTH_DRAGGING_RESOLUTION_IMPERIAL,
  SEGMENT_WIDTH_RESOLUTION_METRIC,
  SEGMENT_WIDTH_CLICK_INCREMENT_METRIC,
  SEGMENT_WIDTH_DRAGGING_RESOLUTION_METRIC,
  BOUNDARY_WIDTH,
} from './constants.js'
import { draggingResize } from './drag_and_drop.js'

import type { Segment, UnitsSetting } from '@streetmix/types'

const SHORT_DELAY = 100

export const RESIZE_TYPE_INITIAL = 0
export const RESIZE_TYPE_INCREMENT = 1
export const RESIZE_TYPE_DRAGGING = 2
export const RESIZE_TYPE_PRECISE_DRAGGING = 3
export const RESIZE_TYPE_TYPING = 4

export function resizeSegment(
  segmentIndex: number,
  resizeType: number,
  width: number,
  units?: UnitsSetting
): number {
  // @TODO: don't read state for units; this is a temp kludge because the drag resizing
  // handler doesn't currently have access to the units. So if it's not provided, grab it
  // from state
  const resolution = resolutionForResizeType(
    resizeType,
    units ?? store.getState().street.units
  )
  width = normalizeSegmentWidth(width, resolution)
  cancelSegmentResizeTransitions()
  store.dispatch(changeSegmentWidth(segmentIndex, width))
  store.dispatch(segmentsChanged())
  return width
}

export function handleSegmentResizeCancel(): void {
  resizeSegment(
    draggingResize.sliceIndex,
    RESIZE_TYPE_INITIAL,
    draggingResize.originalWidth
  )

  handleSegmentResizeEnd()
}

/**
 * Updates street section canvas margins when occupiedWidth is greater than default street extent
 *
 * The default street extent is equal to the street width + (2 * BOUNDARY_WIDTH). When the occupiedWidth
 * is greater than the default street extent, the street-section-outer's scrollLeft no longer works properly.
 *
 * The solution to the above problem, is to update the street-section-canvas' margins and the building widths
 * based on how much the occupiedWidth extends greater than the street width and the default street extent.
 *
 * This function calculates the street margin based on the remainingWidth and compares it to the previous
 * street margin. If the previous street margin is not equal to the current street margin, it will update
 * street-section-canvas' margins accordingly (except in specific situations described within the function)
 *
 */
export function updateStreetMargin(
  canvasRef: HTMLElement | null,
  streetOuterRef: HTMLElement | null,
  dontDelay: boolean = false
): boolean {
  const streetSectionCanvas =
    canvasRef ??
    (document.querySelector('#street-section-canvas') as HTMLElement)
  const streetSectionOuter =
    streetOuterRef ??
    (document.querySelector('#street-section-outer') as HTMLElement)

  const prevMargin =
    Number.parseInt(streetSectionCanvas.style.marginLeft, 10) || BOUNDARY_WIDTH
  const { remainingWidth } = store.getState().street
  let streetMargin = Math.round((-remainingWidth * TILE_SIZE) / 2)

  if (!streetMargin || streetMargin < BOUNDARY_WIDTH) {
    streetMargin = BOUNDARY_WIDTH
  }

  const deltaMargin = streetMargin - prevMargin
  if (deltaMargin === 0) {
    return false
  }

  const maxScrollLeft =
    streetSectionOuter.scrollWidth - streetSectionOuter.clientWidth

  // When scrolled all the way to right and decreasing occupiedWidth, an empty strip
  // of space is shown briefly before being scrolled if updating streetMargin.
  // When scrolled all the way to left and decreasing occupiedWidth, cannot update
  // scrollLeft to keep current segments in view (scrollLeft = 0)
  // Current solution is to delay updating margin until street is not scrolled all
  // the way to right or all the way to left or viewport was resized.
  const delayUpdate =
    !dontDelay &&
    deltaMargin < 0 &&
    (Math.abs(deltaMargin) > streetSectionOuter.scrollLeft ||
      streetSectionOuter.scrollLeft === maxScrollLeft)

  if (!delayUpdate) {
    streetSectionCanvas.style.marginLeft = streetMargin + 25 + 'px'
    streetSectionCanvas.style.marginRight = streetMargin + 25 + 'px'
  }

  return !delayUpdate
}

export function handleSegmentResizeEnd(): void {
  setIgnoreStreetChanges(false)

  updateStreetMargin(null, null, false)
  store.dispatch(segmentsChanged())

  store.dispatch(setDraggingType(DRAGGING_TYPE_NONE))

  window.dispatchEvent(new window.CustomEvent('stmx:TEMP_slice_resize_end'))
}

/**
 * Returns the minimum resolution for segment / street widths.
 * Default return value is in metric units.
 */
export function getSegmentWidthResolution(units: UnitsSetting): number {
  if (units === SETTINGS_UNITS_IMPERIAL) {
    return SEGMENT_WIDTH_RESOLUTION_IMPERIAL
  }

  return SEGMENT_WIDTH_RESOLUTION_METRIC
}

/**
 * Returns the minimum resolution when click-resizing segments
 * Default return value is in metric units.
 */
export function getSegmentClickResizeResolution(units: UnitsSetting): number {
  if (units === SETTINGS_UNITS_IMPERIAL) {
    return SEGMENT_WIDTH_CLICK_INCREMENT_IMPERIAL
  }

  return SEGMENT_WIDTH_CLICK_INCREMENT_METRIC
}

/**
 * Returns the minimum resolution when drag-resizing segments
 * Default return value is in metric units.
 */
export function getSegmentDragResizeResolution(units: UnitsSetting): number {
  if (units === SETTINGS_UNITS_IMPERIAL) {
    return SEGMENT_WIDTH_DRAGGING_RESOLUTION_IMPERIAL
  }

  return SEGMENT_WIDTH_DRAGGING_RESOLUTION_METRIC
}

/**
 * Resolution is the precision at which measurements are rounded to,
 * in order to avoid awkward decimals. There are different levels
 * of precision depending on what action is performed. The resolution
 * is also different depending on whether the street is measured in
 * metric or imperial units. This function returns the minimum resolution
 * depending on the type of resize action and the measurement units.
 */
export function resolutionForResizeType(
  resizeType: number,
  units: UnitsSetting
): number {
  switch (resizeType) {
    case RESIZE_TYPE_INITIAL:
    case RESIZE_TYPE_TYPING:
    case RESIZE_TYPE_PRECISE_DRAGGING:
      return getSegmentWidthResolution(units)
    case RESIZE_TYPE_INCREMENT:
      return getSegmentClickResizeResolution(units)
    case RESIZE_TYPE_DRAGGING:
      return getSegmentDragResizeResolution(units)
    default:
      throw new Error(`Unexpected value: ${resizeType}`)
  }
}

/**
 * Given an input width value, constrains the value to the
 * minimum or maximum value, then rounds it to nearest precision
 */
export function normalizeSegmentWidth(
  width: number,
  resolution: number
): number {
  if (width < MIN_SEGMENT_WIDTH) {
    width = MIN_SEGMENT_WIDTH
  } else if (width > MAX_SEGMENT_WIDTH) {
    width = MAX_SEGMENT_WIDTH
  }
  width = Math.round(width / resolution) * resolution
  // Round to three digit decimal precision
  width = round(width, 3)
  return width
}

/**
 * Given an input height value, constrains the value to the
 * minimum or maximum value, then rounds it to nearest precision
 */
export function normalizeHeightValue(
  height: number,
  resolution: number,
  units: UnitsSetting
): number {
  const maxValue =
    units === SETTINGS_UNITS_IMPERIAL
      ? MAX_ELEVATION_IMPERIAL
      : MAX_ELEVATION_METRIC

  if (height < MIN_ELEVATION) {
    height = MIN_ELEVATION
  } else if (height > maxValue) {
    height = maxValue
  }

  height = Math.round(height / resolution) * resolution
  // Round to three digit decimal precision
  height = round(height, 3)
  return height
}

/**
 * Performs `normalizeSegmentWidth` on an array of segments and
 * returns the new array.
 */
export function normalizeAllSegmentWidths(
  segments: Segment[],
  units: UnitsSetting
): Segment[] {
  return segments.map((segment) => ({
    ...segment,
    width: normalizeSegmentWidth(
      segment.width,
      resolutionForResizeType(RESIZE_TYPE_INITIAL, units)
    ),
  }))
}

export function cancelSegmentResizeTransitions(): void {
  document.body.classList.add('immediate-slice-resize')
  window.setTimeout(function () {
    document.body.classList.remove('immediate-slice-resize')
  }, SHORT_DELAY)
}
