import { vi } from 'vitest'
import request from 'supertest'

import {
  createMockAuthMiddleware,
  setupMockServer,
} from '../../../test/setup-mock-server.ts'
import {
  makeStreetFixture,
  makeUserFixture,
} from '../../../test/model-fixtures.ts'
import { User } from '../../../db/models/index.ts'
import * as streets from '../streets.ts'

const makeStreet = () => {
  const model = {
    ...makeStreetFixture(),
    set: vi.fn(function (this: Record<string, unknown>, payload) {
      Object.assign(this, payload)
    }),
    changed: vi.fn(),
    save: vi.fn(async function (this: Record<string, unknown>) {
      return this
    }),
  }

  return model
}

vi.mock('../../../db/models/index.ts', () => ({
  Sequence: {
    findByPk: vi.fn(async () => ({ seq: 1 })),
    update: vi.fn(async () => [1, [{ seq: 2 }]]),
    create: vi.fn(async () => ({ seq: 1 })),
  },
  Street: {
    build: vi.fn(() => makeStreet()),
    findOne: vi.fn(async () => makeStreet()),
    findAndCountAll: vi.fn(async () => ({
      rows: [makeStreet()],
      count: 1,
    })),
  },
  User: {
    findOne: vi.fn(async () => ({
      ...makeUserFixture({ id: 'user1', authSubject: 'foo|123' }),
      lastStreetId: 1,
      increment: vi.fn(async function (this: Record<string, unknown>) {
        return this
      }),
      update: vi.fn(async function (this: Record<string, unknown>) {
        return this
      }),
    })),
  },
}))

vi.mock('../../../lib/street_schema_update.js', () => ({
  updateToLatestSchemaVersion: vi.fn((streetData) => [false, streetData]),
}))

const street = makeStreetFixture({ id: '3e888ae0-5f48-11e8-82e7-c3447c17015a' })

const { mockUserMiddleware } = createMockAuthMiddleware()

describe('POST api/v1/streets', function () {
  const app = setupMockServer((app) => {
    app.post('/api/v1/streets', mockUserMiddleware, streets.post)
  })

  it('should respond with 201 Created when street data are sent', function () {
    return request(app)
      .post('/api/v1/streets/')
      .type('json')
      .send(JSON.stringify(street))
      .then((response) => {
        expect(response.statusCode).toEqual(201)
        return
      })
  })
})

describe('GET api/v1/streets', function () {
  const app = setupMockServer((app) => {
    app.get('/api/v1/streets', streets.find)
  })

  it('should respond with 200 Ok when streets are returned', function () {
    return request(app)
      .get('/api/v1/streets/')
      .then((response) => {
        expect(response.statusCode).toEqual(200)
        return
      })
  })
})

describe('PUT api/v1/streets/:street_id', function () {
  const app = setupMockServer((app) => {
    app.put('/api/v1/streets/:street_id', mockUserMiddleware, streets.put)
  })

  it('should respond with 204 No Content when street data are sent', function () {
    return request(app)
      .put(`/api/v1/streets/${street.id}`)
      .type('json')
      .send(JSON.stringify(street))
      .then((response) => {
        expect(response.statusCode).toEqual(204)
        return
      })
  })
})

describe('DELETE api/v1/streets/:street_id', function () {
  const app = setupMockServer((app) => {
    app.delete('/api/v1/streets/:street_id', mockUserMiddleware, streets.del)
  })

  it('should respond with 204 No Content when street data are deleted', function () {
    return request(app)
      .delete(`/api/v1/streets/${street.id}`)
      .then((response) => {
        expect(response.statusCode).toEqual(204)
        return
      })
  })

  it('should respond with 403 Forbidden when a different user deletes the street', async () => {
    // The street fixture is owned by `user1`; make the caller `user2`.
    vi.mocked(User.findOne).mockResolvedValueOnce({
      ...makeUserFixture({ id: 'user2', authSubject: 'bar|456' }),
    } as never)

    const response = await request(app).delete(`/api/v1/streets/${street.id}`)

    expect(response.statusCode).toEqual(403)
    expect(response.body.msg).toEqual('Signed-in user cannot delete this street.')
  })
})

describe('GET api/v1/streets/:street_id', function () {
  const app = setupMockServer((app) => {
    app.get('/api/v1/streets/:street_id', streets.get)
  })

  it('should respond with 200 Ok when street is returned', function () {
    return request(app)
      .get(`/api/v1/streets/${street.id}`)
      .then((response) => {
        expect(response.statusCode).toEqual(200)
        return
      })
  })
})
