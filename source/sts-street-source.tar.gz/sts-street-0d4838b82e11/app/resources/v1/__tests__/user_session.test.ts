import request from 'supertest'

import {
  createMockAuthMiddleware,
  setupMockServer,
} from '../../../test/setup-mock-server.ts'
import * as session from '../user_session.ts'

const { mockUserMiddleware } = createMockAuthMiddleware()

describe('DELETE api/v1/users/:user_id', function () {
  const app = setupMockServer((app) => {
    app.delete('/api/v1/users/:user_id', mockUserMiddleware, session.del)
  })

  it('should respond with 204 No content when user signs out', async function () {
    const response = await request(app).delete('/api/v1/users/user1')

    expect(response.statusCode).toEqual(204)
    return
  })
})
