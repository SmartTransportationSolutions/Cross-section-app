import {
  DataTypes,
  Model,
  type InferAttributes,
  type InferCreationAttributes,
  type CreationOptional,
} from 'sequelize'

import roles from '../../data/user_roles.json' with { type: 'json' }
import { sequelize } from '../db.ts'

const validUserRoles = Object.keys(roles)

/*
a little atypical setup here...'id' is usually a unique primary key value
but in this app it is actually the username of the user
*/
export class User extends Model<
  InferAttributes<User>,
  InferCreationAttributes<User>
> {
  declare id: string
  declare authSubject: CreationOptional<string>
  declare displayName: CreationOptional<string>
  declare email: CreationOptional<string>
  declare identities: CreationOptional<unknown>
  declare roles: CreationOptional<string[]>
  declare profileImageUrl: CreationOptional<string>
  declare flags: CreationOptional<unknown>
  declare data: CreationOptional<unknown>
  declare lastStreetId: CreationOptional<number>
  declare createdAt: CreationOptional<Date>
  declare updatedAt: CreationOptional<Date>

  async addRole(newRole: string) {
    if (!this.roles.includes(newRole)) {
      const updatedRoles = [...this.roles, newRole]
      this.roles = updatedRoles
      await this.update({ roles: updatedRoles })
    }
  }

  async removeRole(roleToRemove: string) {
    const newRoles = this.roles.filter((item: string) => item !== roleToRemove)
    this.roles = newRoles
    await this.update({ roles: newRoles })
  }
}

User.init(
  {
    id: {
      allowNull: false,
      primaryKey: true,
      unique: true,
      type: DataTypes.STRING,
    },
    authSubject: {
      type: DataTypes.STRING,
      field: 'auth_subject',
    },
    displayName: {
      type: DataTypes.STRING,
      field: 'display_name',
      validate: {
        len: [0, 30],
      },
    },
    email: { type: DataTypes.STRING, unique: true },
    identities: DataTypes.JSON,
    roles: {
      type: DataTypes.ARRAY(DataTypes.TEXT),
      defaultValue: ['USER'],
      validate: {
        // Check if user role is a valid one against a list of defined roles
        arrayIsValid(userRoles: string[]) {
          if (!userRoles.every((value) => validUserRoles.includes(value))) {
            throw new Error('Role does not match list of valid roles')
          }
        },
      },
    },
    profileImageUrl: {
      // The maximum URL length should be "under 2000 characters"
      // https://stackoverflow.com/questions/417142/what-is-the-maximum-length-of-a-url-in-different-browsers
      // In practice, URLs from various login methods are under 1024
      // characters, but a rare handful of googleusercontent.com URLs are
      // just slightly longer. Bumping to 2048 characters should prevent
      // SQL insert errors that block people from signing in.
      type: DataTypes.STRING(2048),
      field: 'profile_image_url',
    },
    flags: DataTypes.JSON,
    data: DataTypes.JSON,
    lastStreetId: {
      type: DataTypes.INTEGER,
      field: 'last_street_id',
    },
    createdAt: { type: DataTypes.DATE, field: 'created_at' },
    updatedAt: { type: DataTypes.DATE, field: 'updated_at' },
  },
  {
    sequelize,
    modelName: 'User',
    timestamps: true,
    indexes: [
      {
        unique: true,
        fields: ['email'],
      },
      {
        fields: ['auth_subject'],
      },
      {
        unique: true,
        fields: ['id'],
      },
    ],
  }
)
